package com.example.collections

object Main {
  def main(args: Array[String]): Unit = {
    //UC1
    //UC2
    //UC3
    //UC4
    //UC5
    //UC6
    //UC7
    //UC8
    UC9
  }

  def UC9(): Unit = {

    //var title: Option[String] = Some("JavaScript Good Parts")
    var title: Option[String] = None

    println(title)
    println(title.getOrElse("Java Complete Reference"))

    if (title.isEmpty) {
      println("Java Complete Reference")
    } else {
      println(title.get)
    }

  }

  def UC8(): Unit = {

    //var data = (100,"X1","BMW",450000.00,"Black")
    var data = (100, "X1", "BMW", 4500000.00)
    //var data = (100,"X1","BMW",450000.00,"Black")

    var (a, b, _, d) = data
    println(a)
    println(b)
    //println(c)
    println(d)

    println(data.productPrefix)
    println(data.productArity)

    for (value <- data.productIterator) {
      println(value)
    }

    println(data._1)
    println(data._2)
    println(data._3)
    println(data._4)

    println(data)
    println(data.getClass)
  }

  def UC7(): Unit = {

    //var employees = Map()
    //var employees1 = Map[Int,String](100 -> "Rohan",200 -> "Jaggu")
    var employees1 = Map(100 -> "Rohan", 200 -> "Jaggu")

    println(employees1.get(100))
    println(employees1(100))

    var employees4 = employees1 - 200

    var employees2 = employees1 + (300 -> "Mohan")
    var employees3 = employees1 + (200 -> "Raj")

    println(employees1)
    println(employees2)
    println(employees3)
    println(employees4)

    for (value <- employees3) {
      println(value)
    }

    for ((key, value) <- employees3) {
      println(key)
      println(value)
    }

  }

  def UC6(): Unit = {

    var numbers1 = Set(90, 24, 45, 99, 10, 20, 30, 40, 10)
    var numbers2 = Set(4, 5, 8, 12, 10)

    var numbers3 = numbers1 ++ numbers2
    var numbers4 = numbers3 + 100
    var numbers5 = numbers1 - 99

    println(numbers1)
    println(numbers2)
    println(numbers3)
    println(numbers4)
    println(numbers5)

    /*for (value <- numbers1) {
      println(value)
    }*/

  }

  def UC5(): Unit = {
    var numbers1 = List.range(10, 20)
    //var numbers2 = numbers1.drop(4)
    //var numbers2 = numbers1 drop 4
    //var numbers2 = numbers1 dropRight  4
    //var numbers2 = numbers1 take 2
    //var numbers2 = numbers1 takeRight 2
    var numbers2 = numbers1 drop 4 take 3 dropRight 1

    println(numbers1)
    println(numbers2)
  }

  def UC4(): Unit = {
    var numbers1 = List.range(10, 200)

    //numbers1.foreach((el:Int) => println(s"Value is : $el"))
    //var numbers2 = numbers1.filter((el:Int) => el % 50 == 0)
    //var numbers2 = numbers1.filter((el: Int) => el % 5 == 0 || el % 10 == 0)
    //var numbers2 = numbers1.map((el: Int) => el * el * el)
    //var numbers2 = numbers1.reduce((rs: Int,el :Int) => rs + el)
    //var result = numbers1.map((el: Int) => el * el * el).reduce((rs: Int, el: Int) => rs + el)
    //println(result)
  }

  def UC3(): Unit = {
    //var numbers1 = List.fill(10)("Namaste")
    //var numbers1 = List.fill(10,5)("Namaste")
    //var numbers1 = List.range(10, 20,2)
    //var numbers1 = List.iterate[String]("Hello", 10)((value:String) => value + 100)
    var numbers1 = List.tabulate(4, 2)((a: Int, b: Int) => a + b)

    println(numbers1)
  }

  def UC2(): Unit = {
    //var numbers1 = List(5, 34, 12, 76, 45, 32, 45, 12)
    //var numbers1 = List()
    //var numbers1 = List.empty
    //var numbers1 = Nil
    //var numbers1 = 10 :: Nil
    //var numbers1 = 10 :: 20 :: 30 :: Nil
    //var numbers1 = 10 ::(Nil)

    var numbers1 = 10 :: 20 :: 30 :: Nil
    var numbers2 = 40 :: 50 :: 60 :: numbers1
    var numbers3 = numbers1 ::: numbers2

    println(numbers1)
    println(numbers2)
    println(numbers3)

    println(numbers1(0))

    /*var itr = numbers1.iterator
    while (itr.hasNext) {
      println(itr.next)
    }*/

  }

  def UC1(): Unit = {
    var numbers1 = Seq(5, 34, 12, 76, 45, 32, 45)
    //var numbers1 = Seq[Int](5, 34, 12, 76, 45, 32, 45)
    //var numbers1: Seq[Int] = Seq[Int](5, 34, 12, 76, 45, 32, 45)

    println(numbers1)
    println(numbers1.getClass)

    //var numbers2 = numbers1.+:(10)
    var numbers2 = numbers1.+:(10)

    println(numbers1)
    println(numbers2)

  }

}