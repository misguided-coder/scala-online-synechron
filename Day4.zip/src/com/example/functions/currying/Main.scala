package com.example.functions.currying

object Main {

  def main(args: Array[String]): Unit = {

    //var rs = grow()
    //var result = rs()
    //result()

    grow()()()()(25)(30)

    grow()()()

    grow()()

    grow()()()()

    var young = grow()

    //500 loc

    young()()

  }

  def grow() = {
    println("I am just new born")

    () => {
      println("I m little grown!!")

      () => {
        println("I m now young!!")

        () => {
          println("I m now string enough!!")

          (age: Int) => {
            println(s"I m now $age years old and can fight!!")

            (age: Int) => {
              println(s"I m now $age years old and can kill also!!")
            }
          }

        }
      }
    }
  }

}