package com.example.functions

import java.util.Date
import javax.swing.JButton
import java.time.LocalDateTime

object Main {

  def main(args: Array[String]): Unit = {
    //greet()
    //greet
    //hello("Raj")
    //hi("Mohan")
    //hi()

    /*
    greeting("Pintu", 25) //passing arguments by position
    greeting("Pintu")
    greeting()

    greeting(age = 30, name = "Pintu") //passing arguments by their names
    greeting(age = 40) //passing arguments by their names
		*/

    //sendMail()
    //sendSMS("9999030199")

    //val result:Boolean = saveToDB("Ram", 12, "9810000000")
    //val result = saveToDB("Ram", 12, "9810000000")
    /*var result = saveToDB("Ram", 12, "9810000000")
    println(result)
    println(result.getClass)*/

    /*var rs = sum(2,2)
    println(rs)
   */

    /*var rs = diff(10, 5)
    println(rs)
    */

    //var rs = sqrt()
    //var rs = sqrt
    //println(rs)

    
    show("Cool")
    show(24)
    show(2400.00)
    show(new Date())
    show(new JButton())
    show(LocalDateTime.now())
  }

  def show(data:Any) {
    println(s"Data is $data")
    println(s"Data Type is ${data.getClass}")
    
  }
  
  def sqrt = 2 * 2

  //def sqrt() = 2 * 2

  //def sqrt(): Int = 2 * 2

  def diff(arg1: Int, arg2: Int): Int = arg1 - arg2

  //def diff(arg1: Int, arg2: Int): Int = { arg1 - arg2 }

  /*def diff(arg1: Int, arg2: Int): Int = {
    arg1 - arg2
  }*/

  def sum(arg1: Int, arg2: Int): Int = {
    println("Doing calculations")
    println("Done calculations")
    arg1 + arg2
  }

  //def saveToDB(name: String, age: Int, phone: String): Unit = {
  //def saveToDB(name: String, age: Int, phone: String): Boolean = {
  def saveToDB(name: String, age: Int, phone: String): Boolean = {
    println(s"Data $name and $age and $phone saved to DB!!")
    return true
  }

  def sendSMS(mobile: String): Unit = {
    println(s"SMS sent to $mobile!!")
  }

  def sendMail(): Unit = {
    println("Mail has been sent!!")
  }

  def greeting(name: String = "Jaggu", age: Int = 20) {
    println(s"GM Mr $name and Your age is $age")
  }

  def hi(name: String = "Jaggu") {
    println(s"Hi Mr $name")
  }

  def hello(name: String) {
    println(s"Hello Mr $name")
  }

  def greet() {
    println("Hello to Everyone")
  }

}