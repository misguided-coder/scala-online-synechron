package com.example

import java.util.Date
import java.util.ArrayList

object DataTypeDemo {
	def main(args:Array[String]) :Unit = {
		
		var i = 100 //type inference
		println(i)
		println(i.getClass())

		var chapters:Byte = 17 //1 byte in memory
		println(chapters)
		println(chapters.getClass())

		var pages:Short = 240   //2 bytes in memory
		println(pages)
		println(pages.getClass())

 		//4 bytes in memory
		var age:Int = 24 //explicit data type
		println(age)
		println(age.getClass())

		//8 bytes in memory
		var distance:Long = 80000000L
		println(distance)
		println(distance.getClass())

		//4 bytes in memory
		var salary:Float = 160000.00F //explicit data type
		println(salary)
		println(salary.getClass())

		//8 bytes in memory
		var amount:Double = 8000000.00 //type inference
		println(amount)
		println(amount.getClass())


		//1 bit in memory
		var status:Boolean = true				
		println(status)
		println(status.getClass())

	
		//2 bytes in memory
		var letter:Char = 'R'				
		println(letter)
		println(letter.getClass())

		//var data:Any = "I am just some value"
		var data:Any = new ArrayList()
		println(data)
		println(data.getClass())

		var date:AnyRef = new Date()
		//var date:AnyRef = 10    //will not work
		println(date)
		println(date.getClass())
		
		//var value:AnyVal = 900
		//var value:AnyVal = new Date() //will not work
		//var value:AnyVal = new String("Just have fun") //will not work
		//var value:AnyVal = "Just have fun" //will not work
		var value:AnyVal = 'A'
		println(value)
		println(value.getClass())

		var name = null
		println(name)
		//println(name.getClass())

		//mutable data
		var size = "10x6" //type inference
		println(size)
		println(size.getClass())

		size = "20x8"
		println(size)
		println(size.getClass())	
		
		//immutable data
		val title = "Scala Learning"
		println(title)
		println(title.getClass())	
		
		val author:String = "Martin"
		println(author)
		println(author.getClass())	

		//author = "Martin Ow" //will not work
			
	}
}