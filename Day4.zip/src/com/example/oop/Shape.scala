package com.example.oop

//abstract class Shape {
abstract class Shape(var color: String) {

  def info() {
    println("It is all about beautiful shapes!!")
  }

  def draw()
  def paint()
}

//class Circle extends Shape {
class Circle extends Shape("Yellow") {

  override def draw() {
    println(s"Circle is drawn!!")
  }

  override def paint() {
    println(s"Circle is painted with ${this.color} color!!")
  }

}

//class Square extends Shape {
class Square extends Shape("Black") {

  override def draw() {
    println("Square is drawn!!")
  }

  override def paint() {
    println(s"Square is painted with ${this.color} color!!")
  }

}

object ShapeMain {

  def main(args: Array[String]): Unit = {
    UC1
    //UC2()
    //UC3
    //UC4
    //UC5
    //UC6
  }

  def UC1() {

    var shapeA = new Circle()
    var shapeB = new Square()

    shapeA.info
    shapeA.draw()
    shapeA.paint

    shapeB.info
    shapeB.draw()
    shapeB.paint
  }

}
