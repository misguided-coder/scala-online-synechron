package com.example.oop

class Calculator {

  def +(arg1: Long, arg2: Int) {
    println(s"SUM : ${arg1 + arg2}")
  }

  def -(arg1: Long, arg2: Int) {
    println(s"DIFF : ${arg1 - arg2}")
  }

  def *(arg1: Long, arg2: Int = 10) {
    println(s"Multiply : ${arg1 * arg2}")
  }

  def sum(arg1: Long, arg2: Int) {
    println(s"Inside sum(arg1:Long,arg2:Int)!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: Int, arg2: Long) {
    println(s"Inside sum(arg1:Int,arg2:Long)!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: Int, arg2: Int) {
    println(s"Inside sum(arg1:Int,arg2:Int)!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: Int, arg2: Int, arg3: Int) {
    println(s"Inside sum(arg1:Int,arg2:Int,arg3:Int)!!!!")
    println(s"SUM : ${arg1 + arg2 + arg3}")
  }

}

class Size(var width: Int, var height: Int) {

  def info() {
    println(s"Width : $width")
    println(s"Height : $height")
  }

  def plus(size: Size): Size = {
    var w = this.width + size.width
    var h = this.height + size.height
    return new Size(w, h)
  }

  def +(size: Size): Size = {
    var w = this.width + size.width
    var h = this.height + size.height
    return new Size(w, h)
  }

}

object CalculatorMain {

  def main(args: Array[String]): Unit = {

    var size1 = new Size(20, 5)
    var size2 = new Size(10, 5)

    var size3 = size1.plus(size2)
    size3 = size1 plus (size2)
    size3 = size1 plus size2
    size3.info()

    var size4 = size1.+(size2)
    size4 = size1 + (size2)
    size4 = size1 + size2
    size4.info()
    
    val calculator = new Calculator
    calculator.sum(10, 10)
    calculator.sum(10, 10, 10)
    calculator.sum(10, 10L)
    calculator.sum(10L, 10)

    calculator.+(10L, 10)
    calculator + (10L, 10)

    calculator.-(10L, 10)
    calculator - (10L, 10)

    calculator.*(10L, 10)
    calculator * (10L, 10)

    calculator * 10L
  }
}
