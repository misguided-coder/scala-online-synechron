package com.example.oop

class Person(val uid: Int, var name: String, private var phone: String) {

  private def sleep() {
    println("Person sleeping!!")
  }

  def eat() {
    println("Person eating!!")
  }

}

object PersonMain {

  def main(args: Array[String]): Unit = {
    var person = new Person(1000000, "Billu", "9810000000")
    println(person.uid)
    println(person.name)

    person.eat()

  }

}
