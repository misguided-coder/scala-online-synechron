package com.example.traits.exercise

class Erikshaw extends Vehicle with Repairable with Washable {

  override def start() {
    println("Erikshaw engine started with button press!!")
  }
  override def repair() {
    println(s"Erikshaw is sent for repairing!!")
  }

  override def wash() {
    println(s"Erikshaw is sent for washing!!")
  }

}