package com.example.traits.exercise

class Bike extends Vehicle with Acceleratable {

  override def start() {
    println("Bike engine started with key!!")
  }

  override def speedUp() {
    this.speed = this.speed + 20
    println(s"Bike is speeding up and current speed is ${this.speed}!!")
  }

}