package com.example.traits.exercise

class Mechanic {
  def doRepair(vehicle: Repairable) {
    println("Ready to repair!!")
    vehicle.repair()
  }

}