package com.example.traits.exercise

trait Automobile {
  def start()
  def stop()
}