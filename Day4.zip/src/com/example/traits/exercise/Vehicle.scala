package com.example.traits.exercise

abstract class Vehicle extends Automobile with Brakable {
  
  var speed:Int = 20; //miles per hour
  
  override def stop() {
    println("Vehicle engine stopped!!")
  }
  
  override def speedDown() {
    this.speed = this.speed - 10
    println(s"Vehicle is speeding down and current speed is ${this.speed}!!")
  }
  
  
}