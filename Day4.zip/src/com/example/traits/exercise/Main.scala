package com.example.traits.exercise

object Main {

  def main(args: Array[String]): Unit = {

    var car = new Car
    var bus = new Bus
    var bikeA = new Bike with Washable
    var bikeB = new Bike
    var erikshaw = new Erikshaw

    var driver = new Driver
    var racer = new Racer
    var mechanic = new Mechanic
    var houseKeeper = new HouseKeeper

    driver.doDrive(car)
    driver.doDrive(bus)
    driver.doDrive(bikeA)
    driver.doDrive(erikshaw)

    racer.doRace(car)
    racer.doRace(bus)
    racer.doRace(bikeA)

    mechanic.doRepair(car)
    mechanic.doRepair(bus)
    mechanic.doRepair(erikshaw)

    houseKeeper.doWash(car)
    houseKeeper.doWash(erikshaw)
    houseKeeper.doWash(bikeA)
  
  }

}