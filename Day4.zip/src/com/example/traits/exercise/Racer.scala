package com.example.traits.exercise

class Racer {

  def doRace(vehicle: Acceleratable) {
    println("Ready to race!!")
    vehicle.speedUp()
    vehicle.speedUp()
    vehicle.speedUp()
    vehicle.speedUp()
  }

}