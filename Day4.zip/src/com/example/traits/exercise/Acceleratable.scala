package com.example.traits.exercise

trait Acceleratable {
  def speedUp()
}