package com.example.traits

trait A {
  def hello()
}

trait B {
  def hello()
  def hi()
}

trait C {
  def hello()
  def hi()

  def bye() {
    println("Bye....")
  }
}

trait D {

  var data: String = "I can hold data too"

  def hello()
  def hi()

  def bye() {
    println("Bye....")
  }
}

trait E extends A {

}

trait F extends A {

  override def hello() {
    println("Hello....")

  }
}

class Hello extends A {

  override def hello() {
    println("Hello....")

  }
}

abstract class Some {
  def doWork()
}

trait X {
  def exercise() {
    println("Doing exercise....")
  }
}


object Me extends X{
  
}

trait Y {
  def run()
}

class Work extends Some with A with X with Y {

  override def doWork() {
    println("doing some work....")
  }

  override def hello() {
    println("Hello....")
  }

  override def run() {
    println("Doing running....")
  }

}
