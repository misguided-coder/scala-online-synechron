package com.example.exception

case class InvalidAgeException(message: String) extends Exception(message)
case class InvalidRangeException(message: String) extends Exception(message)

//Developer A designed this API to take care of wrong/right input well
object Cinema {

  def watchMovie(age: Int): Unit = {
    if (age <= 14)
      throw new InvalidAgeException("You are not eligible for the movie, Go Home!!")
    if (age > 90)
      throw new InvalidRangeException("You are too old for the movie, Go Home!!")

    println("Enjoy the movie with popcorn!!!!!")
  }

}

object Main {
  def main(args: Array[String]): Unit = {

    try {
      //Cinema.watchMovie(5)
      //Cinema.watchMovie(120)
      Cinema.watchMovie(20)
    } catch {
      case ex: InvalidAgeException   => println(ex.getMessage)
      case ex: InvalidRangeException => println(ex.getMessage)
      case ex: Exception             => println(ex.getMessage)
    } finally {
      println("I am the boss!!")
    }

  }
}

