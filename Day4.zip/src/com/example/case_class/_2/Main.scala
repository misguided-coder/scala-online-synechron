package com.example.case_class._2

case class Course(var id: Int, var title: String)(duration: Int) {

  def display() {
    println(s"Duration : ${this.duration}")
  }
}

case class Present(rollNo:Int)

case object Open
case object Close

object Main {

  def main(args: Array[String]): Unit = {
    //UC1
    UC2
  }

  def UC2() {

    var c1 = new Course(1, "Akka")(40)
    //var c2 = new Course(2, "Play")(60)
    var c2 = new Course(1, "Akka")(70)

    c1.display

    /*c1.id = 5
    c1.title = "Akka Streams"
    c1.duration = 100
     */

    println(c1.hashCode())
    println(c2.hashCode())

    //object equality
    println(c1 == c2)
    println(c1.equals(c2))

    //object identity
    println(c1.eq(c2))

  }

  def UC1() {
    var c1 = new Course(1, "JSP")(24)
    println(c1)
    println(c1.toString())

    println(c1.id)
    println(c1.title)
    //println(c1.duration)

  }

}