package com.example.case_class._3

import java.util.Date

case class Course(var id: Int, var title: String, duration: Int)
case class Present(rollNo: Int)
case object Open
case object Close

object Main {

  def main(args: Array[String]): Unit = {
    //UC1
    //UC2
    UC3
  }

  def chooseValue(data: Any): Unit = data match {
    case 10                    => println("You are very small!!")
    case 40000.00              => println("Your bank balance is low!!")
    case data: Double          => println("You like money!!")
    case data: Date            => println(s"Your DOB is ${data}!!")
    case "Yellow"              => println("Your favourite color is Yellow!!")
    case Present(rollNo)       => println(s"I found this guy ${rollNo} present")
    case Open                  => println("Just open the entry!!")
    case Close                 => println("Just close the entry!!")
    case Course(1, "Akka", 40) => println(s"I want to learn Akka!!")
    case Course(2, "Play", 60) => println(s"I want to learn Play!!")
    case data: Course          => println(s"I want to learn a new course!!")
    case _                     => println(s"I want to learn any course!!")
  }

  def displayAge(age: Int): String = age match {
    case 1 | 5 =>
      "You are new born!!"
    case 10 =>
      "You are very small!!"
    case 20 =>
      "You are young!!"
    case 40 =>
      "You are little old!!"
    case 80 =>
      "You are old!!"
    case _ =>
      "Your age is unknown!!"
  }

  def chooseAge(age: Int): String = {
    if (age >= 1 && age <= 5) {
      "You are new born!!"
    } else if (age == 10) {
      "You are very small!!"
    } else if (age == 20) {
      "You are young!!"
    } else if (age == 40) {
      "You are little old!!"
    } else if (age == 80) {
      "You are old!!"
    } else {
      "Your age is unknown!!"
    }
  }

  def UC3() {

    //var course = new Course(1, "Akka", 40)
    //var course = new Course(2, "Play",60)
    var course = new Course(3, "Scala", 80)
    //chooseValue(course)
    //chooseValue("Yellow")
    //chooseValue(40000.00)
    //chooseValue(Open)
    //chooseValue(Close)
    chooseValue(new Present(1005))

  }

  def UC2() {
    //var rs = chooseAge(20)
    var rs = displayAge(20)
    println(rs)
  }

  def UC1() {

    //var course = new Course(1, "Akka", 40)
    //var course = new Course(2, "Play",60)
    var course = new Course(3, "Scala", 80)
    //var c4 = new Course(4, "Redis",68)
    //var c5 = new Course(5, "Kafka",20)

    course match {

      case Course(1, "Akka", 40) => println(s"I want to learn Akka!!")
      case Course(2, "Play", 60) => println(s"I want to learn Play!!")
      case course: Course        => println(s"I want to learn a new course!!")
      case _                     => println(s"I want to learn any course!!")

    }

  }
}