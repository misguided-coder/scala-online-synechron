package com.example.case_class._1

//case class Course(id: Int, title: String, duration: Int) //hours
case class Course(var id: Int, var title: String, var duration: Int) //hours

object Main {

  def main(args: Array[String]): Unit = {
    //UC1()
    //UC2
    //UC3
    //UC4
    //UC5
    //UC6
    //UC7
    UC8
  }

  def UC8() {

    var c1 = new Course(1, "Akka", 40)
    println(c1.id)
    println(c1.title)
    println(c1.duration)
    c1.duration = 80
    println(c1.duration)
  }

  def UC7() {

    var c1 = new Course(1, "Akka", 40)

    println(c1.productPrefix)
    println(c1.productArity)
    println(c1.productElement(0))
    println(c1.productElement(1))
    println(c1.productElement(2))

    println("==============================")

    var itr: Iterator[Any] = c1.productIterator

    while (itr.hasNext) {
      println(itr.next)
    }

    println("==============================")

    for (value <- itr) {
      println(value)
    }

    println("==============================")

    for (value <- c1.productIterator) {
      println(value)
    }

  }

  def UC6() {

    var c1 = new Course(1, "Akka", 40)
    var c2 = Course(2, "Play", 60)
    var c3 = Course.apply(3, "Akka Streams", 20)

    println(c1)
    println(c2)
    println(c3)
    println(Course.unapply(c1))
  }

  def UC5() {

    var c1 = new Course(1, "Akka", 40)
    var c2 = Course(2, "Play", 60)
    var c3 = Course.apply(3, "Akka Streams", 20)

    println(c1)
    println(c2)
    println(c3)
    println(Course.unapply(c1))
  }

  def UC4() {

    var c1 = new Course(1, "Akka", 40)
    var c2 = Course(2, "Play", 60)
    //var c3 = c1.copy(3)
    //var c3 = c1.copy(id = 3)
    //var c3 = c1.copy(id = 3,title = "SBT")
    //var c3 = c1.copy(id = 3,title = "SBT",duration = 50)
    var c3 = c1.copy(3, "SBT", 50)

    println(c1)
    println(c2)
    println(c3)
  }

  def UC3() {

    var c1 = new Course(1, "Akka", 40)
    var c2 = Course(2, "Play", 60)

    println(c1)
    println(c2)
  }

  def UC2() {

    var c1 = new Course(1, "Akka", 40)
    //var c2 = new Course(2, "Play", 60)
    var c2 = new Course(1, "Akka", 40)

    println(c1.hashCode())
    println(c2.hashCode())

    //object equality
    println(c1 == c2)
    println(c1.equals(c2))

    //object identity
    println(c1.eq(c2))

  }

  def UC1() {
    var c1 = new Course(1, "JSP", 40)
    println(c1)
    println(c1.toString())
  }

}