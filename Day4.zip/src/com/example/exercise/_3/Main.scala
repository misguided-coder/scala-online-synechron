package com.example.exercise._3

object Main {
  def main(args: Array[String]): Unit = {

    var container = EmployeeDAO.selectByID(105)
    //print(container.getOrElse("Rohan").toUpperCase())

    /*for (value <- container) {
      println(value.toUpperCase)
    }*/

    container match {

      case Some(value) => println(s"Value is $value")
      case None        => println("No Value")
      case _           => println("Value is unknown")

    }

  }
}