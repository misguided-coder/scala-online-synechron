package com.example.exercise._3

object EmployeeDAO {

  def selectByID(id: Int): Option[String] = {
    println("Reading data from DB!!")
    //20 JDBC calls
    if (id == 101)
      return Some("Jaggu")
    else if (id == 105)
      return Some("Pintu")
    else
      return None
  }

}