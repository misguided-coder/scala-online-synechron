package com.example.exercise._2

//Developer B is using an API designed long time back by some other developer
object Main {
  def main(args: Array[String]): Unit = {

    DataListService.filter((name: String) => name.length() > 5)
    DataListService.filter((name: String) => name.length() > 8)
    DataListService.filter((name: String) => name.startsWith("R"))
    DataListService.filter((name: String) => name.endsWith("a"))
    DataListService.filter((name: String) => name.contains("t"))

  }
}