def hi() :Unit = {
	println("Hi To Scala")
}

hi()
