object RangeDemo {
	def main(args:Array[String]) :Unit = {
		UC1()
	}

	def UC1() :Unit = {
		//var numbers = Range.inclusive(10000,80000) 
		//var numbers = Range.inclusive(10000,80000,10)
		//var numbers = Range.inclusive(1000,500,-1)
		var numbers = Range.Long.inclusive(100000L,5000000L,100L)
		println(numbers)
	}

}