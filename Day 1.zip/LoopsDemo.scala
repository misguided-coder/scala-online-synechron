object LoopsDemo {
	
	def main(args:Array[String]) :Unit = {
		//UC1()
		UC2()
	}

	def UC2() :Unit = {
		var idx = 0
		do {
			println(s"Welcome to Scala ${idx}!!")
			idx = idx + 1
		} while(idx < 10)
	}

	def UC1() :Unit = {
		var idx = 0
		while(idx < 10) {
			println(s"Welcome to Scala ${idx}!!")
			idx = idx + 1
		}
	}
}