object ForComprehensionDemo {
	def main(args:Array[String]) :Unit = {
		UC1()
		//UC2()
		//UC3()
		//UC4()
		//UC5()
		//UC6()
		//UC7()
		//UC8()
		//UC9()
	}

	def UC1() :Unit = {	
		//range is a lazy collection 
		var numbers = Range.inclusive(10,50) 
		//var numbers = Range.inclusive(10000,80000,10)
		//var numbers = Range.inclusive(1000,500,-1)
		//var numbers = Range.Long.inclusive(100000L,5000000L,100L)

		//generator syntax
		//value <- collection (data source)	

		//for comprehension syntax
		//for(value generator data-source) {
		//	println(value)
		//}

		println(numbers)

		for(value <- numbers) {
			println(value)
		}

	}

}