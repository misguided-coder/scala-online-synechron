import java.util.Date

object ConditionsDemo {
	def main(args:Array[String]) :Unit = {
		//UC1()
		//UC2()
		//UC3()
		//UC4()
		//UC5()
		//UC6()
		//UC7()
		//UC8()
		UC9()
	}

	def UC9() :Unit = {

		//var data:Any = 5
		//var data:Any = "Yellow"
		//var data:Any = 40000.00
		var data:Any = new Date()

		data match {
			case 5 | 6 =>
				println("These are lucky numbers!!")
			case data:Int =>
				println("You like numbers!!")
			case 40000.00 =>
				println("Your bank balance is low!!")
			case data:Double =>
				println("You like money!!")
			case data:Date =>
				println(s"Your DOB is ${data}!!")
			case "Yellow" =>
				println("Your favourite color is Yellow!!")
			case _ =>
				println("Let me guess value!!")
		}
	}


	def UC8() :Unit = {
		var age = 5

		var rs = age match {
			case 1 | 5 =>
				"You are new born!!"
			case 10 =>
				"You are very small!!"
			case 20 =>
				"You are young!!"
			case 40 =>
				"You are little old!!"
			case 80 =>
				"You are old!!"
			case _ =>
				"Your age is unknown!!"
		}

		println(rs)		
	}


	def UC7() :Unit = {
		var age = 5

		age match {
			case 1 | 5 =>
				println("You are new born!!")
			case 10 =>
				println("You are very small!!")
			case 20 =>
				println("You are young!!")
			case 40 =>
				println("You are little old!!")
			case 80 =>
				println("You are old!!")
			case _ =>
				println("Your age is unknown!!")
		}
	}



	//Java way
	def UC6() :Unit = {
		var age = 30

		var result = ""
		
		if(age < 25) {
			result = "You are young!!"
		} else {
			result = "You are old!!"
		}

		println(result)
		println(result.getClass)
	}


	//Scala way
	def UC5() :Unit = {
		var age = 30

		var result = if(age < 25) {
			println("You are little small")
			//"You are young!!"
			println("You are little younger")
			age + 1 
		} else {
			println("You have grown")
			//"You are old!!"
			println("You are very old")
			age + 5 
		}

		println(result)
		println(result.getClass)
	}


	def UC4() :Unit = {
		var age = 30
		var balance = 90000
		
		if(age < 25) {
			println("You are young!!")
			if(balance > 50000) {
				println("You are rich!!")
			}else if(balance <= 50000) {
				println("You are poor!!")
			}
		} else {
			println("You are old!!")
			if(balance <= 50000) {
				println("You are poor!!")
			} else if(balance > 50000) {
				println("You are rich!!")
			}
		}
	}



	def UC3() :Unit = {
		var age = 20
		var balance = 20000
		
		if(age < 25 && balance > 50000) {
			println("You are young and rich!!")
		} else {
			println("You are old and poor!!")
		}
	}


	def UC2() :Unit = {
		var age = 30
		if(age < 25) {
			println("You are young!!")
		} else {
			println("You are old!!")
		}
	}


	def UC1() :Unit = {
		var age = 30
		if(age < 25) {
			println("You are young!!")
		}
	}

}