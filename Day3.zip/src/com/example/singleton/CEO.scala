package com.example.singleton

object CEO {

  var name = "Bill Gates"
  var age = 65

  def info() {
    println(s"Name : $name")
    println(s"Age : $age")
  }
}

object Main {

  def main(args: Array[String]): Unit = {

    //Developer A
    CEO.info

    //Developer B
    CEO.info

  }
}
