package com.example.oop

/*class Employee {
}*/

//class Employee

/*class Employee {
  var name: String = "Raj"
  var salary: Double = 120000.00
}*/

/*class Employee() {
  var name: String = "Raj"
  var salary: Double = 120000.00
}*/

/*class Employee(empName: String, empSalary: Double) {
  var name: String = empName
  var salary: Double = empSalary
}*/

//class Employee(val id: Int, var name: String, var salary: Double)

/*class Employee(val id: Int, var name: String, var salary: Double) {

  def this(id: Int, name: String) {
    this(id, name, 10000.00)
    println("Inside this(id: Int, name: String)!!!!!")
  }

  def this(id: Int) {
    this(id, "Jacky", 10000.00)
    println("Inside this(id: Int)!!!!!")
  }

  def this() {
    //this(1, "Jacky", 10000.00)
    this(1)
    println("Inside this()!!!!!")
  }

}*/

//class Employee(val id: Int = 100, var name: String = "Jaggu", var salary: Double = 25000.00)

class Employee(val id: Int = 100, var name: String = "Jaggu", var salary: Double = 25000.00) {

  var phone: String = "9810000000"

  println("Class initialization started!!")

  def updateSalary(percentage: Double) {
    this.salary = this.salary + (this.salary * percentage)
    println(s"${this.name} salary is updated to ${this.salary}!!!!")
  }

  def applyForLeave() {
    println(s"${this.name} applied for 2 year long leaves!!!!")
  }

  def assignProject(projectName: String) {
    println(s"${this.name} is assigned a new project ${projectName}!!!!!")
  }

  def info() {
    println(s"ID : ${this.id}")
    println(s"NAME : ${this.name}")
    println(s"SALARY : ${this.salary}")
    println("=============================")
  }

  println("Class initialization done!!")

}

object Main {

  def main(args: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC3()
    //UC4()
    //UC5()
    UC6()
  }

  def UC6() {
    var employee1 = new Employee(101, "Mohan", 40000.00)
    //var employee2 = new Employee(102, "Raj", 35000.00)
    var employee2 = new Employee(101, "Mohan", 40000.00)
    
    println(employee1.hashCode())
    println(employee2.hashCode())

    //object equality ----- comparing by content
    println(employee1 == employee2)
    println(employee1.equals(employee2))

    //object identity ----- comparing by memory address
    println(employee1.eq(employee2))
  }

  def UC5() {
    var employee1 = new Employee(101, "Mohan", 40000.00)
    var employee2 = new Employee(102, "Raj", 35000.00)

    employee1 info;
    employee1.updateSalary(.40)
    employee1.applyForLeave()
    employee1.assignProject("Airport Management App")

    employee2.info()

  }

  def UC4() {
    var employee1 = new Employee(101, "Mohan", 40000.00)
    var employee2 = new Employee(102, "Mohan")
    var employee3 = new Employee(103)
    var employee4 = new Employee()
    var employee5 = new Employee(id = 101, name = "Mohan", salary = 40000.00)
    var employee6 = new Employee(name = "Mohan", id = 101, salary = 40000.00)
    var employee7 = new Employee(salary = 40000.00, name = "Mohan", id = 101)
    var employee8 = new Employee(salary = 40000.00, name = "Mohan")
    var employee9 = new Employee(salary = 40000.00)
  }

  def UC3() {
    var employee = new Employee(100, "Mohan", 40000.00)
    println(employee.id)
    println(employee.name)
    println(employee.salary)
    employee.salary = 50000.00
    println(employee.salary)
  }

  def UC2() {
    var employee = new Employee()
    println(employee.name)
    println(employee.salary)
  }

  def UC1() {
    //var employee = new Employee()
    var employee = new Employee
    println(employee)
  }
}
