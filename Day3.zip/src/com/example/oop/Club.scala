package com.example.oop

class Club(var name: String, var rooms: Int, protected var bookedRooms: Int) {

  def info() {
    println(s"Name : ${this.name}")
  }

  private def availSwimmingPool() {
    println(s"SwimmingPool available to be availed!!")
  }

  def availRestaurant() {
    availSwimmingPool
    println(s"Restaurant available to be availed!!")
  }

  def checkAvailability() {
    if (this.bookedRooms < this.rooms) {
      println(s"Rooms Available now : ${this.rooms - this.bookedRooms}")
    }
  }

  def bookRoom(howMany: Int) {
    if (this.bookedRooms < this.rooms) {
      this.bookedRooms = this.bookedRooms + howMany;
      println(s"${howMany} Rooms are booked!!!!")
    }
  }

}

class EliteClub extends Club("Highland Hiliday Club", 150, 0) {

  def bookSuiteRoom(howMany: Int) {
    if (this.bookedRooms < this.rooms) {
      this.bookedRooms = this.bookedRooms + howMany;
      println(s"${howMany} Suite Rooms are booked!!!!")
    }
  }

  def bookPartyLawn() {
    println(s"Party Lawn is booked!!!!")
  }

}

object ClubMain {

  def main(args: Array[String]): Unit = {
    
    val eliteClub = new EliteClub()
    println(eliteClub.name)
    println(eliteClub.rooms)
    
    eliteClub.info()
    eliteClub.availRestaurant
    eliteClub.bookRoom(5)
    eliteClub.checkAvailability()
    eliteClub.bookSuiteRoom(2)
    eliteClub.bookPartyLawn()
    
    val club = new Club("Highland Hiliday Club", 150, 0)

    println(club.name)
    println(club.rooms)
     
    club.info()
    club.availRestaurant
    club.bookRoom(5)
    club.checkAvailability()
  }
}
