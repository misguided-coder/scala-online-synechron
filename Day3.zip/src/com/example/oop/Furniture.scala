package com.example.oop

class Furniture(val id: Int, var material: String) {
  //class Furniture() {

  def make() {
    println(s"Furniture is made of ${this.material}!!")
    //println(s"Furniture is made of Plastic!!")
  }

  def paint() {
    println(s"Furniture is painted with brush!!")
  }
}

//class Chair extends Furniture
//class Chair extends Furniture(5,"Plastic")
class Chair(id: Int, material: String, var legs: Int, var hands: Int) extends Furniture(id, material) {

  def this() {
    this(5, "Plastic", 4, 2)
  }

  def move() {
    println("Chair can move also")
  }
}

class LuxuryChair(id: Int, material: String, legs: Int, hands: Int, var swing: Boolean) extends Chair(id, material, legs, hands) {

}

class Desk(id: Int, material: String, var length: Int) extends Furniture(id, material) {

  def stand() {
    println("Desk can stand also!!")
  }

}

object FurnitureMain {

  def main(args: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC3
    //UC4
    //UC5
    UC6
  }

  def UC6() {
    var furniture: Furniture = new Furniture(1, "Wood")
    var chair: Chair = new Chair(100, "Iron", 4, 2)
    var luxuryChair: LuxuryChair = new LuxuryChair(100, "Cloth", 2, 2, true)
    var desk: Desk = new Desk(105, "Wood", 6)

    var furniture1: Furniture = null
    //furniture1 = new Chair(100, "Iron", 4, 2)
    furniture1 = new LuxuryChair(100, "Cloth", 2, 2, true)
    //furniture1 = new Desk(105, "Wood", 6)

    furniture1.make()
    furniture1.paint()
    
    println(furniture1)
    println(furniture1.isInstanceOf[Furniture])
    println(furniture1.isInstanceOf[Chair])
    println(furniture1.isInstanceOf[LuxuryChair])
    println(furniture1.isInstanceOf[Desk])
    
  }

  def UC5() {
    var chair = new LuxuryChair(100, "Cloth", 2, 2, true)

    println(chair.id)
    println(chair.material)
    println(chair.legs)
    println(chair.hands)
    println(chair.swing)

    chair.make()
    chair.paint()
    chair.move()

  }

  def UC4() {
    var desk = new Desk(105, "Wood", 6)

    println(desk.id)
    println(desk.material)
    println(desk.length)

    desk.make()
    desk.paint()
    desk.stand()

  }

  def UC3() {
    var chair = new Chair(100, "Iron", 4, 2)

    println(chair.id)
    println(chair.material)
    println(chair.legs)
    println(chair.hands)

    chair.make()
    chair.paint()
    chair.move()

  }

  def UC2() {
    var chair = new Chair()
    println(chair.id)
    println(chair.material)

    chair.make()
    chair.paint()
  }

  def UC1() {
    var furniture = new Furniture(1, "Wood")
    furniture.make()
    furniture.paint()
  }

}
