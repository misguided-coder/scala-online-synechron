package com.example.oop

class Generator {

  final val title = "Sequence Generator"

  final def sequence(): Long = {
    return (Math.random() * 10000).toLong
  }

}

class BigGenerator extends Generator {

  /*override def sequence() :Long = {
    return (Math.random() * 99999999).toLong
  }*/

}

object GeneratorMain {

  def main(args: Array[String]): Unit = {

    val generator = new Generator
    println(generator.title)
    println(generator.sequence)

    val bigGenerator = new BigGenerator
    println(bigGenerator.title)
    println(bigGenerator.sequence)

  }
}
