package com.example.exercise._1

//Developer A is designing generic/flexible API for others to use in future
/*
 * Author - Bill Gates
 * Year - 2010
 * Version - 1.0
 */
object CalculatorService {

  def calculate(i: Int, j: Int, fn: (Int, Int) => Unit) {
    println("Preparing for internal calculations.....")
    println("Ready with internal calculations.....")
    fn(i, j) //callback function
    println("Finished with calculations.....")
  }

  def calculate(fn: (Int, Int) => Unit) {
    println("Preparing for internal calculations.....")
    println("Ready with internal calculations.....")
    fn(20, 5) //callback function
    println("Finished with calculations.....")
  }

}