package com.example.exercise._2

//Developer A is designing generic/flexible API for others to use in future
/*
 * Author - Bill Gates
 * Year - 2010
 * Version - 1.0
 */
object DataListService {

  var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
    "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
    "Rose Gulabi", "Laden Humble", "Dawood Raja")

  def filter(fn: (String) => Boolean) {
    println("Preparing for internal iterations.....")
    println("Ready with internal iterations.....")
    println("Filtered Names ==================== ")

    for (name <- names) {
      if (fn(name)) {
        println(name)
      }
    }

    println("Finished with filterization.....")
  }

}