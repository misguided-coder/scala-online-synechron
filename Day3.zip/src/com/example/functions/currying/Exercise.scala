package com.example.functions.currying

object Exercise {

  def main(args: Array[String]): Unit = {
    //UC1()
    //UC2()
    UC3()
  }

  def UC3() {
    var displayDelhiWeather = displayWeather("Delhi")
    var displayPuneWeather = displayWeather("Pune")

    displayDelhiWeather(10)
    displayDelhiWeather(15)
    displayDelhiWeather(18)
    displayDelhiWeather(20)
    displayDelhiWeather(26)

    displayPuneWeather(2)
    displayPuneWeather(4)
    displayPuneWeather(20)
    displayPuneWeather(30)
  }

  def UC2() {
    displayWeather("Delhi")(10)
    displayWeather("Delhi")(12)
    displayWeather("Delhi")(13)
    displayWeather("Delhi")(18)
  }

  def displayWeather(city: String) = {
    (day: Int) =>
      {
        println(s"Weather of $city on $day day is ${(Math.random() * 40).toInt}")
      }
  }

  def UC1() {
    displayWeather("Delhi", 10)
    displayWeather("Delhi", 12)
    displayWeather("Delhi", 20)
    displayWeather("Delhi", 25)
    displayWeather("Delhi", 30)
  }

  def displayWeather(city: String, day: Int) = {
    println(s"Weather of $city on $day day is ${(Math.random() * 40).toInt}")
  }

}