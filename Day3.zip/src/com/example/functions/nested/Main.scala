package com.example.functions.nested

object Main {

  def main(args: Array[String]): Unit = {
    //hello
    greet
  }

  def greet() {
    println("Greet me!!")

    var greetMe = () => {
      println("Greet me too!!")
    }

    greetMe()
  }

  def hello() {
    println("Hello to Everyone")

    def hi() {
      println("Hi to Everyone")

      def bye() {
        println("Bye to Everyone")
      }

      bye()
    }

    hi()
  }

}