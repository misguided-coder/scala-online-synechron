package com.example.functions.anonymous

import java.util.Date

object Main {

  def main(args: Array[String]): Unit = {
    // greet()
    // x()
    // println(x.getClass)
    // println(x)

    //hello("Raj")

    //show("Jacky",40)

    //hi("Ramu")

    var rs = calc()
    println(s"Result : $rs")

  }

   var calc = () => 10 * 5 - 6
 
  //var calc = () => { 10 * 5 - 6 }
  
  /*var calc = () => {
    println("Doing some calculations.......")
    10 * 5 - 6
  }*/

  var hi = (name: String) => println(s"Hi : $name")

  //var hi = (name: String) => { println(s"Hi : $name") }

  var show = (name: String, age: Int) => {
    println(s"Name : $name")
    println(s"Age : $age")
  }

  var hello = (name: String) => {
    println(s"Name : $name")
  }

  //function without name i.e. anonymous function expression
  var x = () => {
    println("Hello to All")
  }

  //function with name declaration
  def greet() {
    println("Hello to Everyone")
  }

}