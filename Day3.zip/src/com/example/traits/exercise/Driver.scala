package com.example.traits.exercise

class Driver {

  def doDrive(vehicle: Vehicle) {
    println("Ready to drive!!")
    vehicle.start()
    vehicle.speedDown()
    vehicle.speedDown()
    vehicle.stop()
  }

}