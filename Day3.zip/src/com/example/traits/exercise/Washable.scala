package com.example.traits.exercise

trait Washable {
  def wash() {
    println("Vehicle sent for washing!!")
  }
}