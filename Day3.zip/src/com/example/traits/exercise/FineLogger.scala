package com.example.traits.exercise

import java.time.LocalDateTime

trait FineLogger {

  def log(message: String): Unit = {
    println(s"INFO ----- ${LocalDateTime.now()} ------ ${message}")
  }

}