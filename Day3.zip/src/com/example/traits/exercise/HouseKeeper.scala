package com.example.traits.exercise

class HouseKeeper {

  def doWash(vehicle: Washable) {
    println("Ready to wash!!")
    vehicle.wash()
  }

}