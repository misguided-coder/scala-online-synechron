package com.example.traits.exercise

class Bus extends Vehicle with Acceleratable with Repairable {

  override def start() {
    println("Bus engine started with key!!")
  }

  override def speedUp() {
    this.speed = this.speed + 10
    println(s"Bus is speeding up and current speed is ${this.speed}!!")
  }

  override def repair() {
    println(s"Bus is sent for repairing!!")
  }

}