package com.example.traits.exercise

class Car extends Vehicle with Acceleratable with Repairable with Washable with FineLogger with Logger {

  override def log(message:String) :Unit = {
    super.log("Car engine started with button press!!")
  }
  
  override def start() {
    log("Car engine started with button press!!")
  }

  override def speedUp() {
    this.speed = this.speed + 20
    println(s"Car is speeding up and current speed is ${this.speed}!!")
  }

  override def repair() {
    println(s"Car is sent for repairing!!")
  }

  override def wash() {
    println(s"Car is sent for washing!!")
  }

}