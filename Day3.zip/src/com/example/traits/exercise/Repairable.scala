package com.example.traits.exercise

trait Repairable {
  def repair()
}