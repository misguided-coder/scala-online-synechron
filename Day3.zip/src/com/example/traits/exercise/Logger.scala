package com.example.traits.exercise

import java.time.LocalDateTime

trait Logger {
 
  def log(message:String) :Unit = {
    println(s"${LocalDateTime.now()} ------ ${message}")
  }

}