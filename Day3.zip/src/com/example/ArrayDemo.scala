package com.example


object ArrayDemo {
	def main(args:Array[String]) :Unit = {
		//UC1()
		//UC2()
		//UC3()
		//UC4()
		//UC5()
		UC6()
	}


	def UC6() :Unit = {

		//var numbers:Array[Array[Int]] = new Array[Array[Int]](2)	
		//var numbers:Array[Array[Int]] = Array.ofDim[Int](2,4)	
		var numbers = Array.ofDim[Int](2,4)	

		numbers(0)(0) = 10
		numbers(0)(1) = 20
		numbers(0)(2) = 30
		numbers(0)(3) = 40

		numbers(1)(0) = 50
		numbers(1)(1) = 60
		numbers(1)(2) = 70
		numbers(1)(3) = 80

		println(s"Rows : ${numbers.size}")
		println(s"First Row Length : ${numbers(0).size}")

		println(numbers(0)(1))
		println(numbers(0)(3))
		println(numbers(1)(3))

	}


	def UC5() :Unit = {

		//var numbers:Array[Int] = new Array[Int](2)	
		var numbers:Array[Int] = Array.ofDim[Int](2)	
	
		
		numbers(0) = 10
		numbers(1) = 20
	
		println(s"Length : ${numbers.size}")

		println(numbers(0))
		println(numbers(1))
	}


	def UC4() :Unit = {

		//var numbers:Array[Array[Int]] = new Array[Array[Int]](2)	
		var numbers = new Array[Array[Int]](2)	
	
		numbers(0) = new Array[Int](4)
		numbers(1) = new Array[Int](4)
		
		numbers(0)(0) = 10
		numbers(0)(1) = 20
		numbers(0)(2) = 30
		numbers(0)(3) = 40

		numbers(1)(0) = 50
		numbers(1)(1) = 60
		numbers(1)(2) = 70
		numbers(1)(3) = 80

		println(s"Length : ${numbers.size}")

		println(numbers(0)(1))
		println(numbers(1)(3))

	}


	def UC3() :Unit = {

		//array declaration plus initialization and population
		var numbers = Array(10,40,35,23,65,34,23,12,67)	
		
		println("Length : "+numbers.size) // Java way
		printf("Length : %s%n",numbers.size) //Java 5 way
		println(s"Length : ${numbers.size}") //Scala way using string template

		println(numbers(0))
		println(numbers(1))
		println(numbers(2))
		println(numbers(3))
		println(numbers(4))
		println(numbers(7))
	}


	def UC2() :Unit = {

		//array declaration
		//var numbers:Array[Int] = new Array[Int](5)	
		var numbers = new Array[Int](5)	

		numbers(0) = 100
		numbers(1) = 101
		numbers(2) = 102
		numbers(3) = 103
		numbers(4) = 104
	
		println(numbers(0))
		println(numbers(1))
		println(numbers(2))
		println(numbers(3))
		println(numbers(4))

	}


	def UC1() :Unit = {

		//array declaration
		var numbers:Array[Int] = new Array[Int](5)	

		//array population
		numbers(0) = 100
		numbers(1) = 101
		numbers(2) = 102
		numbers(3) = 103
		numbers(4) = 104
	
		println(numbers(0))
		println(numbers(1))
		println(numbers(2))
		println(numbers(3))
		println(numbers(4))

		println(numbers)
		println(numbers.getClass())
		println(numbers.getClass)
		println(numbers getClass)
	}

}