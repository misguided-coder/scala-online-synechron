package com.example.companion

class Cat {

  private var name: String = "Jugni"
  
  def drink() {
    println(s"Cat can drink ${Cat.diet} litres milk every day!!")
  }
  
}

object Cat {
  
  private var diet:Int = 5; //litres

  def info() {
    var cat = new Cat()
    println(s"Cat name is : ${cat.name}")
  }

}

object Main {

  def main(args: Array[String]): Unit = {
  
    (new Cat()).drink()
    Cat.info()
  }
}