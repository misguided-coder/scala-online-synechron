package com.example.functions

import java.util.Date
import javax.swing.JButton
import java.time.LocalDateTime

object Calculator {

  def main(args: Array[String]): Unit = {
    sum(10, 2)
    sum(10, 2L)
    sum(10L, 2)
    sum(10, 6, 2)
    sum(10L, 2L)
    sum(1000.00, 50.00)
    sum(1000.00F, 50.00)
    sum(1000.00F, 50.00F)
    sum(1000.00F, 100L)
    sum(1000.00F)
    sum()
  }

  def sum(arg1: Float = 100.00F, arg2: Long = 10L) {
    println("Inside sum(arg1: Float, arg2: Long)!!!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: AnyVal, arg2: AnyVal) {
    println("Inside sum(arg1: AnyVal, arg2: AnyVal)!!!!!!")
    println(s"Arg1 : ${arg1} and Arg2 : ${arg2}")
  }

  def sum(arg1: Long, arg2: Long) {
    println("Inside sum(arg1: Long, arg2: Long)!!!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: Long, arg2: Int) {
    println("Inside sum(arg1: Long, arg2: Int)!!!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: Int, arg2: Long) {
    println("Inside sum(arg1: Int, arg2: Long)!!!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: Int, arg2: Int) {
    println("Inside sum(arg1: Int, arg2: Int)!!!!!!")
    println(s"SUM : ${arg1 + arg2}")
  }

  def sum(arg1: Int, arg2: Int, arg3: Int) {
    println("Inside sum(arg1: Int, arg2: Int, arg3: Int)!!!!!!")
    println(s"SUM : ${arg1 + arg2 + arg3}")
  }

}