package com.example.functions.return_value

object Main {

  def main(args: Array[String]): Unit = {

    /*
    var rs = hello
    println(rs)
    println(rs.getClass)
		*/

    /*var rs = hello()
    rs()
    rs()
    rs()
    rs()
    println(rs.getClass)
	  */

    var rs = show()
    rs()
  }

  def show() = {
    println("Show me the path!!")

    () => {
      println("This is the right path!!")
    }
  }

  def hello() = {
    println("Hello to Everyone")

    var hi = () => {
      println("Hi to Everyone")
    }

    hi
  }

}