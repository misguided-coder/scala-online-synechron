package com.example.for_comprehension

object ForComprehensionDemo {
  def main(args: Array[String]): Unit = {
    //UC1()
    //UC2()
    //UC3()
    //UC4()
    //UC5()
    //UC6()
    //UC7()
    //UC8()
    //UC9()
    //UC10()
    //UC11()
    //UC12()
    //UC13()
    //UC14()
    UC15()
  }

  def UC15(): Unit = {

    var arrays = Array.ofDim[Int](10, 5)

    for (row <- 0 to 9; column <- 0 to 4) {
      arrays(row)(column) = (Math.random() + row + column).toInt
    }

    for (array <- arrays; value <- array) {
      println(value)
    }

  }

  def UC14(): Unit = {

    var array = Array.ofDim[String](10, 5)

    //for (row <- 0 to 9; column <- 0 to 4) {
    for (row <- 0 until array.length; column <- 0 until array(row).length) {
      //array(row)(column) = s"Row : $row & Column : $column"
      array(row)(column) = s"Row : ${row + 100} & Column : ${column + 5}"
    }

    for (row <- 0 to 9; column <- 0 to 4) {
      println(array(row)(column))
    }

  }

  def UC13(): Unit = {

    var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
      "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
      "Rose Gulabi", "Laden Humble", "Dawood Raja")

    for (
      name <- names;
      if name.startsWith("R") && name.length() > 4;
      nameChanged = name.toUpperCase()
    ) {
      println(s"Name is : $nameChanged")
    }

  }

  def UC12(): Unit = {

    var names = Array("Rani", "Ramu", "Chachu", "Ganshu", "Papa Jon", "Rancho", "Sudhir",
      "Pintu", "Jaggu", "Chandu", "Gabbar", "Lalu Yadav", "Kalia Khatarnak", "Kallu Don", "Rani Patiala",
      "Rose Gulabi", "Laden Humble", "Dawood Raja")

    //for (name <- names; if name.startsWith("R")) {
    //for (name <- names; if name.startsWith("R") &&  name.length() > 4) {
    for (name <- names; if name.startsWith("R") && name.length() > 4; nameChanged = name.toUpperCase()) {
      println(s"Name is : $nameChanged")
    }

  }

  //loop with on the way intermediate computations plus filter together
  def UC11(): Unit = {

    for (i <- 10 to 50; rs = i * i; if rs > 800 || rs % 100 == 0) {
      println(s"I : $i & Square is : $rs")
    }

  }

  //loop with on the way intermediate computations
  def UC10(): Unit = {

    for (i <- 10 to 50; rs = i * i) {
      println(s"I : $i & Square is : $rs")
    }

  }

  //loop with on the way filter
  def UC9(): Unit = {

    //for (i <- 10 to 500; if i % 10 == 0) {
    for (i <- 10 to 500; if i % 10 == 0 || i % 5 == 0) {
      println(s"I : $i")
    }

  }

  //nested loops
  def UC8(): Unit = {

    for (i <- 1 to 5; j <- 1 to 2; k <- 1 to 4) {
      println(s"I : $i & J : $j & K : $k")
    }

  }

  def UC7(): Unit = {

    //var array:Array[Int] = new Array[Int](10)
    //var array = new Array[Int](10)
    var array = Array.ofDim[Int](10)

    for (idx <- 0 until array.length) {
      array(idx) = 100 + idx
    }

    for (value <- array) {
      println(value)
    }
  }

  def UC6(): Unit = {

    var array = Array(10, 30, 40, 50, 60, 70, 80, 90, 100, 110)

    for (value <- array) {
      println(value)
    }
  }

  def UC5(): Unit = {

    //var array:Array[Int] = Array(10,30,40,50,60,70,80)
    var array = Array(10, 30, 40, 50, 60, 70, 80, 90, 100, 110)

    //for (idx <- 0 until 7) {
    for (idx <- 0 until array.length) {
      println(array(idx))
    }
  }

  def UC4(): Unit = {
    //for (value <- 10 to 50) {
    //for (value <- 10 to 50 by 5) {
    //for (value <- 10 until 50) {
    //for (value <- 10 until 50 by 5) {
    for (value <- 40 to 20 by -5) {
      println(value)
    }
  }

  def UC3(): Unit = {
    //var numbers:Range = Range.inclusive(100, 800, 50)
    //var numbers:Range = 10 to 50
    //var numbers = 10 to 50
    var numbers = 10 to 50 by 5

    println(numbers)

    for (value <- numbers) {
      println(value)
    }
  }

  def UC2(): Unit = {
    //var numbers = Range.inclusive(100,800,50)
    //var numbers = Range.inclusive(100,50,-5)
    var numbers = Range.Long.inclusive(100L, 500L, 100L)

    println(numbers)

    for (value <- numbers) {
      println(value)
      println(value.getClass)
    }
  }

  def UC1(): Unit = {
    //range is a lazy collection
    var numbers = Range.inclusive(10, 50)
    //var numbers = Range.inclusive(10000,80000,10)
    //var numbers = Range.inclusive(1000,500,-1)
    //var numbers = Range.Long.inclusive(100000L,5000000L,100L)

    //generator syntax
    //value <- collection (data source)

    //for comprehension syntax
    //for(value generator data-source) {
    //	println(value)
    //}

    println(numbers)

    for (value: Int <- numbers) {
      println(value)
      println(value.getClass)
    }

  }

}