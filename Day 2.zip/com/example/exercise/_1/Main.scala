package com.example.exercise._1

//Developer B is using an API designed long time back by some other developer
object Main {
  def main(args: Array[String]): Unit = {

    //wrong use of anonymous function
    var sum = (a: Int, b: Int) => {
      println(s"Result : ${a + b}")
    }

    CalculatorService.calculate(sum)

    //right use of anonymous function
    /*
     * 1. Use anonymous function when functionality is small
     * 2. Use anonymous function when functionality is one timer
     * 3. Use anonymous function when functionality is inline
     */
    //Behavioral injection 
    CalculatorService.calculate((a: Int, b: Int) => { println(s"Result : ${a - b}") })
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a - b}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a * b}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a / b}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a % b}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a * a * b}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${b * b * a}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a + b + 10}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a / b + 10}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a / b - 10}"))
    CalculatorService.calculate((a: Int, b: Int) => println(s"Result : ${a * b + 1}"))

    CalculatorService.calculate(1000,100,(a: Int, b: Int) => println(s"Subtract : ${a - b}"))
   
  }
}